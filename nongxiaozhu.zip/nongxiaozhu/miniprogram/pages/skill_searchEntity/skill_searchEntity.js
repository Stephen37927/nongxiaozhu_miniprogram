const db=wx.cloud.database()
//获取集合
const goods_col=db.collection('entity')

Page({

    /**
     * 页面的初始数据
     */
    data: {
        tabs:[
            {
              id:0,
              name:"动物",
              isActive:true
            },
            {
              id:1,
              name:"植物",
              isActive:false
            }
          ],
        animals:[
            {
            }
          ],
        plants:[
            {
            }
        
          ],
        isLoading: false
    },

    bindDownLoad: function () {
        setTimeout(()=>{
          this.setData({
            isLoading:false
          })
          this.onLoad() // 下拉刷新触发的事件
        },2000)
      },

      onLoad(){
        this.loadListData_animal()
        this.loadListData_plant()
    },

    //加载列表，动物
  async loadListData_animal(){
      let res=await goods_col.where({category: '动物'}).get()
      this.setData({
          animals:res.data
      })
  },

  //加载列表，植物
  async loadListData_plant(){
    let res=await goods_col.where({category: '植物'}).get()
    this.setData({
        plants:res.data
    })
},

    handleTabsItemChange(e){
        const {index}=e.detail;
        let {tabs}=this.data;
        tabs.forEach((v,i)=>i===index?v.isActive=true:v.isActive=false);
        this.setData({
            tabs
        })
      }

   
})
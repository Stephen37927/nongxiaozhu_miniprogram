const db=wx.cloud.database()
//获取集合
const goods_col_hot=db.collection('article').orderBy('hits','desc')
const goods_col_date=db.collection('article').orderBy('public_time','desc')

Page({

  /**
   * 页面的初始数据
   */
  data: {
    tabs:[
        {
          id:0,
          name:"热榜",
          isActive:true
        },
        {
          id:1,
          name:"最新",
          isActive:false
        }
      ],
    articles_hot:[
        {
        }
      ],
    articles_date:[
        {
        }
    
      ],
    isLoading: false
  },

  bindDownLoad: function () {
    setTimeout(()=>{
      this.setData({
        isLoading:false
      })
      this.onLoad() // 下拉刷新触发的事件
    },2000)
  },


  onLoad(){
      this.loadListData_hot()
      this.loadListData_date()
  },

  //加载列表_hot
  async loadListData_hot(){
      let res=await goods_col_hot.limit(20).get()
      //console.log(res)
      this.setData({
          articles_hot:res.data
      })
  },

   //加载列表_date
   async loadListData_date(){
    let res=await goods_col_date.limit(20).get()
    //console.log(res)
    this.setData({
        articles_date:res.data
    })
},

  handleTabsItemChange(e){
    const {index}=e.detail;
    let {tabs}=this.data;
    tabs.forEach((v,i)=>i===index?v.isActive=true:v.isActive=false);
    this.setData({
        tabs
    })
  },
  
})
// pages/skill_searchArticle/skill_searchArticle.js
const DB = wx.cloud.database().collection("article"); // 读取云数据库marketPrice，将数据加载到DB中

Page({
    data: {
        searchKey: "", // 搜索框的值
        noneView: false, // 是否显示未找到提示
        showArticle: false, // 是否显示文章列表
        articleList: [], // 数据库中读取的文章列表
        articles:[], // 需要传到前端的搜索结果
    },

    // 搜索
    search: function (e) {
        var that = this;
        var searchText = that.data.searchKey; // 搜索框的值
        var noneView = true; // 未找到提示
        var showArticle = false; // 隐藏文章列表
        wx.cloud.database().collection("article").get({
            success(res) {
                console.log("请求成功", res);
                // 将res中的data赋值给页面中的datalist
                that.setData({
                    articleList: res.data
                })
                var resultList = [];
                if (searchText != "") {
                    // 模糊查询 循环查询每篇文章的title字段
                    for (var i = 0,len = that.data.articleList.length; i < len; i++) {
                        var num = that.data.articleList[i].title.indexOf(searchText);
                        for(var j in that.data.articleList[i].tabs){
                            var num2 = that.data.articleList[i].tabs[j].indexOf(searchText);
                            if(num2 != -1){
                                break;
                            }
                        }
                        if (num != -1 || num2 != -1) { // 匹配的放入集合
                            resultList.push(that.data.articleList[i]);
                            noneView = false; // 隐藏未找到提示
                            showArticle = true; // 展示文章列表
                        }
                    }
                    that.setData({
                        noneView: noneView, // 隐藏未找到提示
                        showArticle: showArticle, // 隐藏文章列表
                    })
                    if(noneView == false && showArticle == true){
                        that.setData({
                            articles: resultList
                        })
                    }
                } else {
                    that.setData({
                        noneView: true, // 显示未找到提示
                        showArticle: false, // 隐藏文章列表
                    })
                }
            }
        })
    },

    // 搜索框的值
    searchInput: function (e) {
        // 当删除input的值为空时
        if (e.detail.value == "") {
            this.setData({
                articleList: false, // 隐藏文章列表
            });
        }
        this.setData({
            searchKey: e.detail.value
        })
    },
})
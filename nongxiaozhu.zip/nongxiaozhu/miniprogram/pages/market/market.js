var wxCharts = require('../../utils/wxcharts')
var daylineChart = null; // 横坐标：x天前
const DB = wx.cloud.database().collection("marketPrice"); // 读取云数据库marketPrice，将数据加载到DB中

Page({
  data: {
    region: [],
    datalist: [],
    ifCondition: false, // 判断无数据提示是否出现
    options: [{
      type_id: '001',
      type_name: '猪肉'
    }, {
      type_id: '002',
      type_name: '牛肉'
    }, {
      type_id: '003',
      type_name: '油桃'
    }],
    selected: {},
    predictPrice:0
  },

  change(e) {
    this.setData({
      selected: {
        ...e.detail
      }
    })
    wx.showToast({
      title: `${this.data.selected.id} - ${this.data.selected.name}`,
      icon: 'success',
      duration: 1000
    })
    this.getMarketPrice();
  },
  close() {
    // 关闭select
    this.selectComponent('#select').close()
  },

  getUserProvince: function (e) {
    this.setData({
      region: e.detail.value //将用户选择的省市区赋值给region
    });
    this.getMarketPrice();
  },

  getMarketPrice: function () {
    var that = this;
    // logs:要显示的云数据库的集合名称
    wx.cloud.database().collection("marketPrice").get({
      success(res) {
        console.log("请求成功", res)
        // 将res中的data赋值给页面中的datalist
        that.setData({
          datalist: res.data
        })
        var legendList = [];
        var found = 0;
        var maxPrice = 0, minPrice = 1000;
        if (that.data.selected.name != null && that.data.region != null) {
          for (var i in that.data.datalist) {
            if (that.data.datalist[i].name == that.data.selected.name && that.data.datalist[i].location.province == that.data.region[0] && that.data.datalist[i].location.city == that.data.region[1] && that.data.datalist[i].location.region == that.data.region[2]) {
              var sum = 0,
                count = 0;
              for (var j in that.data.datalist[i].prices) {
                var obj = that.data.datalist[i].prices[j].price;
                sum += obj;
                count++;
                legendList.push(obj);
                if(obj > maxPrice){
                  maxPrice = obj;
                }
                if(obj < minPrice){
                  minPrice = obj;
                }
              }
              var predictPrice = (sum / count).toFixed(2); // 计算平均值作为预测价格
              that.setData({ // 通过setData方法将预测价格传输到wxml中
                predictPrice: predictPrice
              })
              var windowWidth = 320;
              try {
                // 获取系统信息：设备型号、设备像素比、可用窗口宽度（高度）、语言、版本、平台
                var res = wx.getSystemInfoSync();
                windowWidth = res.windowWidth;
              } catch (e) {
                console.error('getSystemInfoSync failed!');
              }
              daylineChart = new wxCharts({
                canvasId: 'marketPrice', // canvas名称
                type: 'line', // 折线图变曲线图
                categories: ['0', '1', '2', '3', '4', '5', '6'], // categories X轴
                animation: true, // 动画
                series: [{
                  name: '价格',
                  data: legendList, // 折线图数据显示
                  format: function (val) {
                    return val.toFixed(2) + "元/斤";
                  },
                }],
                xAxis: {
                  disableGrid: true
                },
                yAxis: {
                  title: '价格(元）',
                  format: function (val) {
                    return val.toFixed(2);
                  },
                  max: (maxPrice*1.1).toFixed(2),
                  min: (minPrice*0.9).toFixed(2)
                },
                width: windowWidth,
                height: 400,
                dataLabel: false,
                dataPointShape: true,
                extra: {
                  lineStyle: 'curve'
                }
              });
              found = 1;
              that.data.ifCondition = false;
              that.setData({
              ifCondition:that.data.ifCondition
              })
              break;
            }
          }
          console.log(found);
        }
        if(found == 0){
          that.data.ifCondition = true;
          that.setData({
            ifCondition:that.data.ifCondition
          })
        }
      },
      fail(res) {
        console.log("请求失败", res)
      }
    })
  },

  monthTouchHandler: function (e) {
    // 点击显示详细信息
    daylineChart.showToolTip(e, {
      background: '#377D63',
      format: function (item, category) {
        return (7 - category) + '天前 ' + item.name + ':' + item.data
      }
    });
  },

  /** 生命周期函数——监听页面加载 */
  onLoad: function (options) {
    this.getMarketPrice();
  },
})
const db=wx.cloud.database()
//获取集合
const goods_col=db.collection('article')


Page({

    /**
     * 页面的初始数据
     */
    data: {
        titleInput:"",
        contentInput:"",
        author:"",
        avatar:""
    },

    getTitle(e){
        this.setData({
            titleInput:e.detail.value
        })
    },

    getContent(e){
        this.setData({
            contentInput:e.detail.value
        })
    },

    async publicTap(e){
        let res = wx.getStorageSync('userInfo')
        if(res != null && res != '' && res.nickName != '' && res.nickName != null){
            this.setData({
                author: res.nickName,
                avatar: res.avatarUrl
        })
        //引用util
        var util = require("../../utils/time.js");
        if(this.data.titleInput!=null && this.data.titleInput.trim()!='' && this.data.contentInput!=null && this.data.contentInput.trim()!=''){
            goods_col.add({
                data:{
                    author: this.data.author,
                    avatar: this.data.avatar,
                    content: this.data.contentInput,
                    hits: 0,
                    public_time: util.js_date_time(new Date().getTime()),
                    title: this.data.titleInput
                }
            })
            wx.showToast({
              title: '发布成功',
              icon: 'success',
              duration: 1000, //提示保留1秒
              success: function () {
                setTimeout(function () {
                wx.switchTab({
                  url: '/pages/skill_main/skill_main',
                }) 
                }, 1200); //停1.2秒返回主页面
                }
            })
        }
        else{
            wx.showToast({
                title: '输入不能为空',
                icon: 'error',
                duration: 1000
              })
        }

        }
        else{
            wx.showToast({
                title: '请先登录',
                icon: 'error',
                duration: 1000, //提示保留1秒
                success: function () {
                  setTimeout(function () {
                  wx.switchTab({
                    url: '/pages/skill_main/skill_main',
                  }) 
                  }, 1200); //停1.2秒返回主页面
                  }
              })
        }  
    },

    /**
     * 生命周期函数--监听页面加载
     */
    onLoad(options) {   
        
    },

    /**
     * 生命周期函数--监听页面初次渲染完成
     */
    onReady() {
        
    },

    /**
     * 生命周期函数--监听页面显示
     */
    onShow() {
        
    },

    /**
     * 生命周期函数--监听页面隐藏
     */
    onHide() {

    },

    /**
     * 生命周期函数--监听页面卸载
     */
    onUnload() {

    },

    /**
     * 页面相关事件处理函数--监听用户下拉动作
     */
    onPullDownRefresh() {

    },

    /**
     * 页面上拉触底事件的处理函数
     */
    onReachBottom() {

    },

    /**
     * 用户点击右上角分享
     */
    onShareAppMessage() {

    }
})

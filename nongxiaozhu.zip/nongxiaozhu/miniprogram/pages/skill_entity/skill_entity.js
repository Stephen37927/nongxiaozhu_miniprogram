const db = wx.cloud.database()
const goods_col = db.collection('entity')
const article_col = db.collection('article')
const _ = db.command

Page({
    data: {
        image:"",
        name:"",
        product:"",
        feature:"",
        details:"",
        methods:"",
        articles:[]
    },

    //生命周期函数--监听页面加载
    onLoad(options) {
        let{entity_id}=options
        this.loadData(entity_id)
        this.loadArticle(entity_id)
    },

    //加载数据
    async loadData(id){
        let res = await goods_col.doc(id).get()
        this.setData({
            image: res.data.picture,
            name: res.data.name,
            product: res.data.product,
            feature: res.data.feature,
            details: res.data.details,
            methods: res.data.methods
        })
    },

    //加载文章
    async loadArticle(id){
        let res = await goods_col.doc(id).get()
        let arr = res.data.articles
        let res_article = await article_col.where({_id: _.in(arr)}).get()
        this.setData({
            articles: res_article.data
        })
    }
    
})
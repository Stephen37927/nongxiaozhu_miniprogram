const db=wx.cloud.database()
const goods_col=db.collection('article')
Page({

    /**
     * 页面的初始数据
     */
    data: {
        articles:[]
    },

    async loadArticles(name){
        let res=await goods_col.where({author: name}).get()
        this.setData({
            articles:res.data
        })
    },

    warning(){
        wx.showToast({
            title: '请先登录',
            icon: 'error',
            duration: 1000, //提示保留1秒
            success: function () {
              setTimeout(function () {
              wx.switchTab({
                url: '/pages/mine_main/mine_main',
              }) 
              }, 1200); //停1.2秒返回主页面
              }
          })
    },

    /**
     * 生命周期函数--监听页面加载
     */
    onLoad(options) {
        if(options.name.trim() == '' || options == null){
            //请先登录warning
            this.warning();
        }
        else{
            let name = options.name
            this.loadArticles(name)
        }
    },

    /**
     * 生命周期函数--监听页面初次渲染完成
     */
    onReady() {

    },

    /**
     * 生命周期函数--监听页面显示
     */
    onShow() {

    },

    /**
     * 生命周期函数--监听页面隐藏
     */
    onHide() {

    },

    /**
     * 生命周期函数--监听页面卸载
     */
    onUnload() {

    },

    /**
     * 页面相关事件处理函数--监听用户下拉动作
     */
    onPullDownRefresh() {

    },

    /**
     * 页面上拉触底事件的处理函数
     */
    onReachBottom() {

    },

    /**
     * 用户点击右上角分享
     */
    onShareAppMessage() {

    }
})
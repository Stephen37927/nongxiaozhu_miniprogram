const db = wx.cloud.database()
const goods_col = db.collection('article')
const _ = db.command

Page({

    /**
     * 页面的初始数据
     */
    data: {
        article_id:'',
        detail:{},
        dataObj:"",
        time:"",
        saved_icon:'',
        self:'',
        ifSaved:false
    },

    /**
     * 生命周期函数--监听页面加载
     */
    onLoad(options) {
        let{article_id}=options
        this.loadData(article_id)
        this.getData(article_id)
        this.addHits(article_id)
        this.setData({article_id: article_id})
        //判断是否已收藏
        let user = wx.getStorageSync('userInfo')
        let arr;
        if(user != null && user != '' && user.nickName != '' && user.nickName != null){
            db.collection('userInfo').where({nickName: user.nickName}).get().then(res=>{
                arr = res.data[0].saved
                if(arr.indexOf(article_id)>=0){
                    this.setData({ifSaved: true})
                }else{
                    this.setData({ifSaved: false})
                }
            });
        }else{
            this.setData({ifSaved: false})
        }
    },
    //加载详情数据
    async loadData(id){
        let res = await goods_col.doc(id).get()
        this.setData({
            detail:res.data
        })
    },

    //获取数据
    getData(id){
        goods_col.doc(id).get({
            success:res=>{
                this.setData({
                    dataObj:res.data
                })
            }
        })
    },

    //点击量增加
    addHits(id){
        goods_col.doc(id).update({
            // data 传入需要局部更新的数据
            data: {
                hits: _.inc(1)
            }
          })
    },

    save(){
        let res = wx.getStorageSync('userInfo')
        if(res != null && res != '' && res.nickName != '' && res.nickName != null){
            let ifSaved = !this.data.ifSaved
            this.setData({
            // 简写
            ifSaved
            })
            //提示用户
            wx.showToast({
                title: ifSaved ? '收藏成功' : '取消收藏',
                icon:'success'
            })
            //操作数据库
            if(ifSaved){
                db.collection('userInfo').where({nickName: res.nickName}).update({
                    data:{
                    saved:_.push(this.data.article_id)
                    }
                })
            }
            else{
                db.collection('userInfo').where({nickName: res.nickName}).update({
                    data:{
                    saved:_.pull(this.data.article_id)
                    }
                })
            }
        }
        else{
            wx.showToast({
                title: '请先登录',
                icon: 'error'
              })
        }
    },

    /**
     * 生命周期函数--监听页面初次渲染完成
     */
    onReady() {

    },

    /**
     * 生命周期函数--监听页面显示
     */
    onShow() {

    },

    /**
     * 生命周期函数--监听页面隐藏
     */
    onHide() {

    },

    /**
     * 生命周期函数--监听页面卸载
     */
    onUnload() {

    },

    /**
     * 页面相关事件处理函数--监听用户下拉动作
     */
    onPullDownRefresh() {

    },

    /**
     * 页面上拉触底事件的处理函数
     */
    onReachBottom() {

    },

    /**
     * 用户点击右上角分享
     */
    onShareAppMessage() {

    }
})
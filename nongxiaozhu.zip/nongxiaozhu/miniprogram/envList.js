const envList = [{"envId":"cloud1-4g4epobn84975060","alias":"cloud1"}]
const isMac = false
module.exports = {
    envList,
    isMac
}